module.exports = {
    "ATLASDB": "mongodb+srv://dbadmin:YVr3YKLvmAZjDlPF@express.oh34o.mongodb.net/cars?retryWrites=true&w=majority"
}